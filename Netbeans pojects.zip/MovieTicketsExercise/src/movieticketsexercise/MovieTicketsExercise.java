/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package movieticketsexercise;

import java.util.Scanner;

/**
 *
 * @author lab_RahulWylie
 */
public class MovieTicketsExercise {
    
    public int age; 
    public String day;
    
    

        
        public static void main(String[] args) {
        
        Scanner input = new Scanner(System.in);
        System.out.println("Enter your age:");
         int age = input.nextInt();
        
        System.out.println("Enter Day of the week:");
         String day = input.nextLine();
         
         switch(Weeknd){
             case 1:
                 System.out.println("Monday");
                 break;
             case 2:
                 System.out.println("Tuesday");
                 break;
             case 3:
                  System.out.println("Wednesday");
                  break;
             case 4:
                 System.out.println("Thursday");
                 break;
             case 5:
                 System.out.println("Friday");
                 break;
             case 6:
                 System.out.println("Saterday");
                 break;
             case 7:
                 System.out.println("Sunday");
                 
                 default
                     
         
         
         }
         
         
         
    }
    
}
