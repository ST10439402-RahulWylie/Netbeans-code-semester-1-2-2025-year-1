/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pkgwhile.loops;

import java.util.Scanner;

/**
 *
 * @author lab_Rahul_Wylie
 */
public class WhileLoops {

    
    public static void main(String[] args) {
       int randomNumber = (int)(Math.random() * 100) + 1;
       Scanner scanner = new Scanner(System.in);
       int guess = 1;
       int attempts = 0;
       
        System.out.println("Welcome to the Number Guessing Game!");
        System.out.println("Try to guess the number between 1 and 100.");
        
        while(guess != randomNumber){
            System.out.println("Enter your guess!");
            guess = scanner.nextInt();
            attempts++;
            
            if(guess < randomNumber){
                System.out.println("Too low! Try again.");
                }else if(guess > randomNumber){
                System.out.println("Too high! Try again.");}
        }
        System.out.println("Congratulations! You guessed the number " 
                + randomNumber + " in " + attempts + " attempts."  );
        scanner.close();
        
    }
}
