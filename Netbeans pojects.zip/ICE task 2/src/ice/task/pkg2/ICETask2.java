/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ice.task.pkg2;

/**
 *
 * @author RahulWYlie ST10439402
 */
import javax.swing.JOptionPane;
public class ICETask2 {

    
    public static void main(String[] args) {
     //prompt for hourly wage
     String wageInput = JOptionPane.showInputDialog(null,"Enter employee's hourly wage" , "salary dialog 1" , JOptionPane.INFORMATION_MESSAGE);
     double hourlyWage = Double.parseDouble(wageInput);
     
     //Prompt for number dependents
     String dependentsInput = JOptionPane.showInputDialog(null, "How many dependents?" , "Salary dialog 2", JOptionPane.QUESTION_MESSAGE);
     int dependents = Integer.parseInt(dependentsInput);
     
     //Calculate weekly salary
     double weeklySalary = hourlyWage * 37.5;
             
    
     //Display the final message
             JOptionPane.showMessageDialog(null, "Weekly salary is $" + String.format("%.2f", weeklySalary)
             + "\ndeductions will be made for " + dependents + "dependents" , "Message", JOptionPane.INFORMATION_MESSAGE);                                              
     
    
    
    
    }
    
}
//----------------------0o0o0o0o0o0o0o end if file-------------------------//