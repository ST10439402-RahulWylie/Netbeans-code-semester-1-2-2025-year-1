/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package paradiseinfo;

/**
 *
 * @author lab_Rahul Wylie_ST10439402
 */
public class TestInfo {

    
    public static void main(String[] args) {
        System.out.print("Calling method from another class:");
        ParadiseInfo.displayInfo();
    }
    
}
