/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package paradiseinfo;

/**
 *
 * @author lab_Rahul Wylie_ST10439402
 */
public class ParadiseInfo {

   
    public static void main(String[] args) {
        
        displayInfo();
        
    }
    
    public static void displayInfo(){
        System.out.println("Paradise Day Spa wants to pamper you. ");
        System.out.println("We willl make you look good. ");
    
    
    }
            
            
            
    
}
