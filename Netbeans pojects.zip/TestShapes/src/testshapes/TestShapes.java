/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package testshapes;

/**
 *
 * @author ST10439402
 */
public class TestShapes {

    
    public static void main(String[] args) {
         Circle circle = new Circle("Red", 5.0);
        System.out.println(circle.toString());
        System.out.println("Circle Area: " + circle.calculateArea());
        System.out.println();

        Rectangle rectangle = new Rectangle("Blue", 4.0, 6.0);
        System.out.println(rectangle.toString());
        System.out.println("Rectangle Area: " + rectangle.calculateArea());
    }
    
    
}
