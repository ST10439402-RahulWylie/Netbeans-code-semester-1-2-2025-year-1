/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package classexercise_sorting;

import java.util.Arrays;
import javax.swing.JOptionPane;

/**
 *
 * @author Rahul_Wylie
 */
public class ClassExercise_Sorting {

    public static void main(String[] args) {
        int[][] originalArray = {
            {12, 20, 221, 390, 29},
            {50, 288, 19, 65, 44},
            {55, 18, 68, 11, 2},
            {54, 81, 38, 420, 590},};

        //Get user input using JOptioPane
        int row = Integer.parseInt(JOptionPane.showInputDialog("Eter the row index (0-3):"));
        int col = Integer.parseInt(JOptionPane.showInputDialog("Eter th colum idex (0-4):"));

        //Display selected element
        int value = originalArray[row][col];
        JOptionPane.showMessageDialog(null, "Value at (" + row + "," + col + ") is: " + value);

        //Sort ascending and desceding per row
        int[][] ascendingArray = new int[originalArray.length][originalArray[0].length];
        int[][] descendingArray = new int[originalArray.length][originalArray[0].length];

        // ----Sorting----
        // Outer loop: looping through number of rows in array
        for (int i = 0; i < originalArray.length; i++) {

            //Copying each row to 10 array per iteration
            // copying(original array [entire row at index i], newLength [returns number of columns in row i]}
            int[] ascendingRow = Arrays.copyOf(originalArray[i], originalArray[i].length);

            //Bubble sort asceding
            for (int j = 0; j < ascendingRow.length - 1; j++) {
                for (int k = 0; k < ascendingRow.length - 1; k++) {
                    if (ascendingRow[k] > ascendingRow[k + 1]) {
                        int temp = ascendingRow[k];
                        ascendingRow[k] = ascendingRow[k + 1];
                        ascendingRow[k + 1] = temp;
                    }
                }
            }

            //Store in ascending array
            ascendingArray[i] = Arrays.copyOf(ascendingRow, ascendingRow.length);

            // --REPEAT POCESS FOR DESCEDING --
            // copyOf(oiginal array [entire row at index i], newlength [returns number o colums in row i]}
            int[] descendingRow = Arrays.copyOf(originalArray[i], originalArray[i].length);

            //Bubble sort asceding
            for (int j = 0; j < descendingRow.length - 1; j++) {
                for (int k = 0; k < descendingRow.length - 1; k++) {
                    if (descendingRow[k] > descendingRow[k + 1]) {
                        int temp = descendingRow[k];
                        descendingRow[k] = descendingRow[k + 1];
                        descendingRow[k + 1] = temp;
                    }
                }
            }
            descendingArray[i] = Arrays.copyOf(descendingRow, descendingRow.length);
        }
        //print array
        System.out.println("Original Array:");
        print2DArray(originalArray);

        System.out.println("\nAscending Row-wise Sorted Array:");
        print2DArray(ascendingArray);

        System.out.println("\nDescending Row-wise Sorted Array:");
        print2DArray(ascendingArray);

    }

    //Help method to pit a 2D array
    public static void print2DArray(int[][] array) {
        for (int[] row : array) {
            for (int val : row) {
                System.out.printf("%5d", val);
            }
            System.out.println();

        }
    }
}
