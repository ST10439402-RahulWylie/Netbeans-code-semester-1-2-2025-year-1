/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package methodexamples;

/**
 *
 * @author Rahul Wylie-ST10439402
 */
public class MethodExamples {

    
    public static void main(String[] args) {
        
        greetUser("Alice"); //Calls greetUser
       
    }
    //------------------------------------------------------------------------//
    
    //-----------------------------------------------------------------------//
    // Passing parameter with Viod return type
    public static void greetUser(String name)
    { 
        System.out.println("Hello," + name + "! Welcome to Java.");
    
        //Call addNumbers method
        int sum = addNumbers(5, 10);
        System.out.println("sum of numbers: " + sum);
        
        // Call the getPiValue method
        double pi = getPiValue();
        System.out.println("The vlaue of Pi is: " + pi);
        
        //Call the calculateArea Mehtod
        double area = calculateArea(4.5 , 2.0);
        System.out.println("Rectangle area: " + area);
        
        
       //Call the dsiaplayFullName method
       displayFullName("Alice" , "Johnson");
    }
    //-----------------------------------------------------------------------//
    
    //-----------------------------------------------------------------------//
    //Passing parameters with integer return Type
    public static int addNumbers(int num1, int num2){
    
    int result = num1 + num2;
    return result;
    
    }
          
    //----------------------------------------------------------------------//
    
    //--------------------------------------------------------------------//
    //no parameters with double return type
   public static double getPiValue(){
           
           //double num = 3.14;
           //return num;
           
           return 3.14;
     }
   
   //--------------------------------------------------------------------//
   //-------------------------------------------------------------------//
   //passing parameters with double return type
   public static double calculateArea(double length, double width){
   
   return length * width;
   
   
   }
   //-------------------------------------------------------------------------//
   //------------------------------------------------------------------------//
   //passing parameters with void return type
   public static void displayFullName(String firstName , String lastName){
   
       System.out.println("Full Name: " + firstName + " " + lastName);
   }
   //-------------------------------------------------------------------------//
   
   
   //-------------------------------0o0o0o0o0 End of file 0o0o0o0o0o0o0o------//
   
}
