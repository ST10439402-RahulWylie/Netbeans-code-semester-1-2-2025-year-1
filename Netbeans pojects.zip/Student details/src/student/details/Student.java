/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package student.details;

/**
 *
 * @author lab_services_student
 */

public class Student{
    
     // Students attributes
    private int StudentId;
    private String FirstName;
    private String LastName;
    private int Age;
    private double GPA;

    
    
    
    
    
    //Master conductor
       public Student(int StudentId, String FirstName, String LastName, int Age, double GPA )
        {
            
            this.FirstName = FirstName;
            this.LastName  = LastName;
            this.Age = Age;
            this.GPA = GPA ; 
        }            
                    
    //Getters and setters
        public int getStudentId()
        {

            return StudentId;

        }
          
        public void setStudentId(int StudentId)
        {
           this.StudentId = StudentId;
        }

        public String getFirstName()

        {
           return FirstName;
        }
        
        public void setFirstName(String FirstName)
        {
            this.FirstName = FirstName;
        
        }
        
        public String getLastName()
        {
            return LastName;
        
        }
        
        public void setLastName(String LastName)
        {
            this.LastName = LastName;
        
        }
        
        public int getAge()
        {
            return Age;
        }
        
        public void setAge(int Age)
        {
            this.Age = Age;
        }
        
        public double getGPA()
        {
            return GPA;
        }
        
        public void setGPA(double GPA)
        {
            this.GPA = GPA;
        }
        
        //---------------------------------------------------------------------
        //Print out students details
        
        public void printDetails()
        {
            System.out.println("Student ID"  + StudentId);
            System.out.println("Student First Name" + FirstName);
            System.out.println("Student Last Name" + LastName);
            System.out.println("Student GPA" + GPA);
        }



    }          
                
                   
