package student.details;


/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */


import student.details.Student;

/**
 *
 * @author RahulWylie ST10439402
 */

    public static void main(String[] args) {
        
            //Example usage
            Student student = new Student(101, "Rahul", "Wylie",3.8);
            student.setStudentid();
            student.printInfo();
                    




        }

    
}

