/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package personutils;

/**
 *
 * @author lab_RahulWylie
 */
public class PersonUtils {

   /*
    Reference Method sourced from ChatGPT (2025)
    Chat was asked to Create a method that passes through two string
    variables that return a string, concatenating the agruements.
   
    */
    public String getFullName(String firstName, String lastName){
    
    return firstName + "  " + lastName;
    
    }
    public int getYearOfBirth(int currentYear, int age){
        return currentYear - age;
        }
    public boolean isAdult(int age){
    
    return age >= 18;
    }
    
    
    }

    

