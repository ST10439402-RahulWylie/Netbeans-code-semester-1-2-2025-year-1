/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */

import org.junit.Test;
import static org.junit.Assert.  *;
import personutils.PersonUtils;
/**
 *
 * @author RahulWylie
 */
public class PersonUnitTest {
    
   PersonUtils utils = new PersonUtils();
   /*
   assertEquals is used to check whether two value are exactly the same.
   These values couble be numbers, charaters, strings, or even objects
   (as long as they comparable.)When writing tests, this assertion
   
 
   */
   @Test
   public void testGetFullName(){
   
   String result = utils.getFullName("Jane" , "Doe");
   
   assertEquals("Full name should be 'Jane Doe'","Jane Doe",result);
   }
    
   @Test
   public void testGetYearOfBirth(){
   int result = utils.getYearOfBirth(2025, 23);
   
   
   assertEquals("Year of birth should be 2002", 2002, result);
   
   }
   /*assertTrue checks whether given condition or expression is true. 
    It's a commonly used to test boolean values or logical expressions that should evaluate to true in the context of your program.
    You pass a condition to assertTrue. If the condition is false (as expected) the test passes.
    If the condition is true, the test fails and provides a message stating that the condition was expected to be false. */
   
   @Test
   public void testIsAdult(){
   assertTrue("Age 18 should be considered adult", utils.isAdult(18));
   assertFalse("Age 17 should not be considered adult", utils.isAdult(17));
   }
   
}
