/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package program.override.and.overload;

/**
 *
 * @author lab_services_student
 */
public abstract class Animal {
    private String name;
    
    public Animal (String name)
    {
         this.name = name;
    }
    public String getName()
    {
        return name;
    }
    
    //Abstract method
    public abstract void makesound();
    
    //Overiden toString()
    @Override
    public String toString()
    {
        return "Animal:" + name;
    }

    void makeSound() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
