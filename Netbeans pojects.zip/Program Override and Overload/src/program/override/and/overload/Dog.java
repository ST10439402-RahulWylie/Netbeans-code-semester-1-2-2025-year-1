/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package program.override.and.overload;

/**
 *
 * @author lab_services_student
 */
public class Dog extends Animal {
    //Dog costructor
    public Dog(String name)
    {
        super(name);
    }
    
    @Override
    public void makeSound()
    {
        System.out.println(getName() + "says Woof!");
    }
    
    //Overloadig example
    public void makeSound(int times)
    {
        for(int i = 0; i < times; i++)
        {
            System.out.println(getName() + "says: Woof!");
        }
    }
}
