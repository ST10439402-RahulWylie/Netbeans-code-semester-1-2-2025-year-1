/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package program.override.and.overload;

/**
 *
 * @author RahulWylie
 */
public class ProgramOverrideAndOverload {

    
    public static void main(String[] args) {
        Animal[] animals = new Animal[3];
        animals[0] = new Dog("Rex");
        animals[1] = new Cow("Bessie");
        animals[2] = new Snake("Slither");
                
          //Demostrating polymorphism ad dynamic binding
          for (Animal a : animals) {
               a.makeSound();//Calls correct method dependig on actual object
               System.out.println(a.toString());
          }
          //Demonstrating overloading
          Dog dog = new Dog("Buddy");
          dog.makeSound(3);
    }
    
    
}
