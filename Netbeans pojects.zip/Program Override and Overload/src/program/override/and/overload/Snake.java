/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package program.override.and.overload;

/**
 *
 * @author lab_services_student
 */
public class Snake extends Animal {
    //Snake constructor
    public Snake(String name)
    {
          super(name);
    }
    
    @Override
    public void makeSound(){
        System.out.println(getName() + "says: Hiss!");
    
    }
    
}
