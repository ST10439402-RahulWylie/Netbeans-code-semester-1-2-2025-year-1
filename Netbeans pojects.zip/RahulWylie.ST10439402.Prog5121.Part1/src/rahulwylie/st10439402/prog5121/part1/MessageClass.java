/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package rahulwylie.st10439402.prog5121.part1;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;
import javax.swing.JOptionPane;

/**
 *
 * @author Rahul_Wylie
 */
public final class MessageClass {
   
     // Core arrays for Part 3 requirements
    private final ArrayList<String> sentMessageArray;    // All sent messages
    private final ArrayList<String> messageHashArray;    // Message hashes
    private final ArrayList<String> messageIDArray;      // Message IDs
    private final ArrayList<String> senderArray;         // Senders
    private final ArrayList<String> recipientArray;      // Recipients
    
    // Original functionality
    private final ArrayList<String> sentMessages;
    private int totalMessagesSent;
    private final Scanner input;
    private String currentUser = "User";
    
    public MessageClass() throws IOException {
        // Initialize arrays
        sentMessageArray = new ArrayList<>();
        messageHashArray = new ArrayList<>();
        messageIDArray = new ArrayList<>();
        senderArray = new ArrayList<>();
        recipientArray = new ArrayList<>();
        
        // Original functionality
        sentMessages = new ArrayList<>();
        totalMessagesSent = 0;
        input = new Scanner(System.in);
        
        // Load existing messages from JSON
        loadMessagesFromJSON();
    }
    
    public void setCurrentUser(String username) {
        this.currentUser = username;
    }
    
    // Generate random 10-digit message ID
    private String generateMessageID() {
        Random rand = new Random();
        StringBuilder id = new StringBuilder();
        for (int i = 0; i < 10; i++) {
            id.append(rand.nextInt(10));
        }
        return id.toString();
    }
    
    // Check if message ID is exactly 10 characters
    public boolean checkMessageID(String messageID) {
        return messageID.length() == 10;
    }
    
    // Check if recipient cell number is valid
    public boolean checkRecipientCell(String cellNumber) {
        if (cellNumber.startsWith("+27") && cellNumber.length() == 12) {
            String digitsOnly = cellNumber.substring(3);
            for (int i = 0; i < digitsOnly.length(); i++) {
                if (!Character.isDigit(digitsOnly.charAt(i))) {
                    System.out.println("Invalid recipient cell number. "
                            + "Must be +27 followed by exactly 9 digits.");
                    return false;
                }
            }
            System.out.println("Recipient cell number is valid.");
            return true;
        }
        System.out.println("Invalid recipient cell number format.");
        return false;
    }
    
    // Create message hash: first2digits:messageNum:FIRSTWORD:LASTWORD
    public String createMessageHash(String messageID, int messageNum,
            String message) {
        String[] words = message.trim().split("\\s+");
        String firstWord = words[0].toUpperCase();
        String lastWord = words[words.length - 1].toUpperCase();
        String firstTwoDigits = messageID.substring(0, 2);
        
        return firstTwoDigits + ":" + messageNum + ":" + firstWord + ":" 
                + lastWord;
    }
    
    
    public void sendMessage() throws IOException {
        String messageID = generateMessageID();

        // Get recipient
        System.out.print("Enter recipient cell number (e.g., +27821234567): ");
        String recipient;
        do {
            recipient = input.nextLine();
        } while (!checkRecipientCell(recipient));

        // Get message
        String message;
        do {
            System.out.print("Enter your message (max 250 characters): ");
            message = input.nextLine();

            if (message.length() > 250) {
                System.out.println("Please enter a message less than 250 "
                        + "characters.");
            } else if (message.length() > 50) {
                System.out.println("️Message is too long to be sent.");
            } else if (message.trim().isEmpty()) {
                System.out.println("Message cannot be empty.");
            } else {
                System.out.println("Message ready to send.");
            }
        } while (message.length() > 250 || message.trim().isEmpty());

        // Process message
        totalMessagesSent++;
        String messageHash = createMessageHash(messageID, totalMessagesSent, 
                message);

        // Store in arrays
        sentMessageArray.add(message);
        messageHashArray.add(messageHash);
        messageIDArray.add(messageID);
        senderArray.add(currentUser);
        recipientArray.add(recipient);

        // Create message details for display
        String messageDetails = "Message ID: " + messageID +
                              "\nMessage Hash: " + messageHash +
                              "\nRecipient: " + recipient +
                              "\nMessage: " + message;

        sentMessages.add(messageDetails);

        // Save to JSON file
        saveMessageToJSON(messageID, recipient, message, messageHash);

        // Show success message
        JOptionPane.showMessageDialog(null, messageDetails, "Message Sent",
                JOptionPane.INFORMATION_MESSAGE);
        System.out.println("Message sent successfully!");
    }
    
    //Display sender and recipient of all sent messages
    public void displaySenderAndRecipient() {
        if (sentMessageArray.isEmpty()) {
            System.out.println("No messages have been sent yet.");
            return;
        }
        
        System.out.println("\n=== SENDER AND RECIPIENT DETAILS ===");
        for (int i = 0; i < sentMessageArray.size(); i++) {
            System.out.println("Message " + (i + 1) + ":");
            System.out.println("Sender: " + senderArray.get(i));
            System.out.println("Recipient: " + recipientArray.get(i));
            System.out.println("------------------------");
        }
    }
    
    //Display the longest sent message
    public void displayLongestMessage() {
        if (sentMessageArray.isEmpty()) {
            System.out.println("No messages have been sent yet.");
            return;
        }
        
        String longestMessage = "";
        int longestLength = 0;
        int longestIndex = 0;
        
        for (int i = 0; i < sentMessageArray.size(); i++) {
            if (sentMessageArray.get(i).length() > longestLength) {
                longestLength = sentMessageArray.get(i).length();
                longestMessage = sentMessageArray.get(i);
                longestIndex = i;
            }
        }
        
        System.out.println("\n=== LONGEST SENT MESSAGE ===");
        System.out.println("Message: " + longestMessage);
        System.out.println("Length: " + longestLength + " characters");
        System.out.println("Sender: " + senderArray.get(longestIndex));
        System.out.println("Recipient: " + recipientArray.get(longestIndex));
    }
    
    //Search for message by recipient
    public void searchMessagesByRecipient() {
        if (recipientArray.isEmpty()) {
            System.out.println("No messages have been sent yet.");
            return;
        }
        
        System.out.print("Enter recipient number to search: ");
        String searchRecipient = input.nextLine();
        
        boolean found = false;
        System.out.println("\n=== MESSAGES FOR RECIPIENT: " + searchRecipient
                + " ===");
        
        for (int i = 0; i < recipientArray.size(); i++) {
            if (recipientArray.get(i).equals(searchRecipient)) {
                System.out.println("Message ID: " + messageIDArray.get(i));
                System.out.println("Sender: " + senderArray.get(i));
                System.out.println("Message: " + sentMessageArray.get(i));
                System.out.println("------------------------");
                found = true;
            }
        }
        
        if (!found) {
            System.out.println("No messages found for recipient: " + 
                    searchRecipient);
        }
    }
    
    //Delete message using hash
    public void deleteMessageByHash() {
        if (messageHashArray.isEmpty()) {
            System.out.println("No messages available to delete.");
            return;
        }
        
        System.out.print("Enter Message Hash to delete: ");
        String searchHash = input.nextLine();
        
        for (int i = 0; i < messageHashArray.size(); i++) {
            if (messageHashArray.get(i).equals(searchHash)) {
                System.out.println("Deleting message: " + 
                        sentMessageArray.get(i));
                
                // Remove from all arrays
                sentMessageArray.remove(i);
                messageHashArray.remove(i);
                messageIDArray.remove(i);
                senderArray.remove(i);
                recipientArray.remove(i);
                
                // Also remove from original sentMessages if exists
                if (i < sentMessages.size()) {
                    sentMessages.remove(i);
                }
                
                System.out.println("Message deleted successfully.");
                return;
            }
        }
        
        System.out.println("Message hash not found.");
    }
    
    /* Reference Method sourced from ChatGPT (2025) 
    Chat was asked to read a JSON file into an array that contains the
    stored message hashes 
    */
    private void loadMessagesFromJSON() throws IOException {
        File file = new File
        ("src/rahulwylie/st10439402/prog5121/part1/chatMessages.json");
        
        if (!file.exists()) {
            return; // No file to load
        }
        
        BufferedReader reader = new BufferedReader(new FileReader(file));
        String line;
        StringBuilder content = new StringBuilder();
        
        while ((line = reader.readLine()) != null) {
            content.append(line);
        }
        reader.close();
        
        // Simple JSON parsing - extract messages
        String jsonContent = content.toString();
        if (jsonContent.contains("\"message\"")) {
            String[] parts = jsonContent.split("\"message\":\\s*\"");
            for (int i = 1; i < parts.length; i++) {
                String message = parts[i].split("\"")[0];
                message = message.replace("\\\"", "\"");
                // Add to arrays (simplified loading)
                sentMessageArray.add(message);
            }
        }
    }
    
    //Save messages to JSON file
    private void saveMessageToJSON(String messageID, String recipient, 
            String message, String messageHash) throws IOException {
            File file = new File
        ("src/rahulwylie/st10439402/prog5121/part1/chatMessages.json");
        ArrayList<String> messages = new ArrayList<>();

        // Read existing messages
        if (file.exists()) {
            BufferedReader reader = new BufferedReader(new FileReader(file));
            String line;
            StringBuilder content = new StringBuilder();
            
            while ((line = reader.readLine()) != null) {
                content.append(line.trim());
            }
            reader.close();
            
            String jsonContent = content.toString();
            if (jsonContent.startsWith("[") && jsonContent.endsWith("]")) {
                jsonContent = jsonContent.substring(1, jsonContent.length()
                        - 1).trim();
                if (!jsonContent.isEmpty()) {
                    String[] entries = jsonContent.split("},\\s*\\{");
                    for (String entry : entries) {
                        entry = entry.trim();
                        if (!entry.startsWith("{")) entry = "  {" + entry;
                        if (!entry.endsWith("}")) entry = entry + "}";
                        messages.add(entry);
                    }
                }
            }
        }

        // Add new message
        String newMessage = "  {\n" +
                "    \"messageID\": \"" + messageID + "\",\n" +
                "    \"recipient\": \"" + recipient + "\",\n" +
                "    \"message\": \"" + message.replace("\"", "\\\"") + "\",\n"+
                "    \"messageHash\": \"" + messageHash + "\"\n" +
                "  }";
        messages.add(newMessage);

        // Write back to file
        FileWriter writer = new FileWriter(file);
        writer.write("[\n");
        for (int i = 0; i < messages.size(); i++) {
            writer.write(messages.get(i));
            if (i < messages.size() - 1) writer.write(",\n");
        }
        writer.write("\n]");
        writer.close();
    }
    
    // Original methods for backward compatibility
    public String printMessages() {
        if (sentMessages.isEmpty()) {
            return "No messages have been sent yet.";
        }
        
        StringBuilder allMessages = new StringBuilder("All Sent Messages:\n\n");
        for (int i = 0; i < sentMessages.size(); i++) {
            allMessages.append("Message ").append(i + 1).append(":\n");
            allMessages.append(sentMessages.get(i)).append("\n\n");
        }
        return allMessages.toString();
    }
    
    public int returnTotalMessages() {
        return totalMessagesSent;
    }
    
}


 //--------------------------------0o0o0o0o end file 0o0o-------------------//



