/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package rahulwylie.st10439402.prog5121.part1;

/**
 *
 * @author lab_RahulWylie
 */
public class LoginClass {
    private UserClass registeredUser;
    
     public boolean checkUserName(String username) {
        if (username.contains("_") && username.length() <= 5) {
            System.out.println("Username successfully captured.");
            return true;
        } else {
            System.out.println("Username is not correctly formatted, "
                    + "please ensure that your username contains an underscore "
                    + "and is no more than five characters in length.");
            return false;
        }
    }

    public boolean checkPasswordComplexity(String password) {
        if (password.matches("^(?=.*[A-Z])(?=.*\\d)(?=.*[@#$%^&+=!]).{8,}$")) {
            System.out.println("Password successfully captured.");
            return true;
        } else {
            System.out.println("Password is not correctly formatted; "
                    + "please ensure that the password contains at least "
                    + "eight characters, a capital letter, a number, and a "
                    + "special character.");
            return false;
        }
    }
 /*
    Reference Method sourced from ChatGPT (2025)
    Chat was asked to create a regular expression-based cell phone checker 
    that will ensure that the cell phone number conforms to the following
    for a whatsapp application
     */
     public boolean checkCellPhoneNumber(String cellNumber) {
        if (cellNumber.matches("^\\+27\\d{9}$")) {
            System.out.println("Cell phone number successfully added.");
            return true;
        } else {
            System.out.println("Cell phone number incorrectly formatted "
                    + "or does not contain international code.");
            return false;
        }
    }

    public String registerUser(String username, String password, String 
            cellNumber, String firstName, String lastName) {
        boolean validUsername = checkUserName(username);
        boolean validPassword = checkPasswordComplexity(password);

        if (validUsername && validPassword) {
            registeredUser = new UserClass(username, password, cellNumber,
                    firstName, lastName);
            return "User successfully captured.";
        } else {
            return "Registration failed due to incorrect username or "
                    + "password format.";
        }
    }

    public boolean loginUser(String username, String password) {
    if (registeredUser == null) return false;
    return registeredUser.getUsername().equals(username) && registeredUser.getPassword().equals(password);
}

public String returnLoginStatus(String username, String password) {
    return "Welcome " + registeredUser.getFirstName() + " " + registeredUser.getLastName() + " it is great to see you again.";
}
  public String getRegisteredUsername() {
    return registeredUser.getUsername();
}  
    
    
}
    
    
//--------------0o0o0o0o end file 0o0o0--------------------------------------//    
    
    

