/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package rahulwylie.st10439402.prog5121.part1;

import java.util.Scanner;
import java.io.IOException;
/**
 *
 * @author lab_RahulWylie
 */
public class RahulWylieST10439402Prog5121Part1 {
    

   public static void main(String[] args) throws IOException {
        Scanner input = new Scanner(System.in);
        LoginClass login = new LoginClass();
        MessageClass messageSystem = new MessageClass();

        boolean exitApp = false;
        boolean registered = false;

        while (!exitApp) {
            if (!registered) {
                System.out.println("\n=== REGISTER ===");

                String firstName, lastName, username, password, cellNumber;

                System.out.print("Enter your first name: ");
                firstName = input.nextLine();

                System.out.print("Enter your last name: ");
                lastName = input.nextLine();

                do {
                    System.out.print("Enter a username: ");
                    username = input.nextLine();
                } while (!login.checkUserName(username));

                do {
                    System.out.print("Enter a password: ");
                    password = input.nextLine();
                } while (!login.checkPasswordComplexity(password));

                do {
                    System.out.print("Enter your SA cell phone number (e.g.,"
                            + " +27821234567): ");
                    cellNumber = input.nextLine();
                } while (!login.checkCellPhoneNumber(cellNumber));

                String registrationMsg = login.registerUser(username, password, 
                        cellNumber, firstName, lastName);
                System.out.println(registrationMsg);
                registered = true;
            }
            
            // Login process
            String loginUser = "";
            String loginPass = "";

            do {
                System.out.println("\n=== LOGIN ===");
                System.out.print("Enter username to login: ");
                loginUser = input.nextLine();

                if (!login.getRegisteredUsername().equals(loginUser)) {
                  System.out.println("Username incorrect. Please try again.\n");
                }
            } while (!login.getRegisteredUsername().equals(loginUser));

            do {
                System.out.print("Enter password to login: ");
                loginPass = input.nextLine();

                if (!login.loginUser(loginUser, loginPass)) {
                    System.out.println
                ("Password incorrect. Please try again.\n");
                }
            } while (!login.loginUser(loginUser, loginPass));

            System.out.println(login.returnLoginStatus(loginUser, loginPass));
            messageSystem.setCurrentUser(loginUser);
            
            // Main application menu
            boolean inMainMenu = true;
            while (inMainMenu) {
                System.out.println("\n--- QUICKCHAT MENU ---");
                System.out.println("1. Send Messages");
                System.out.println("2. Show recently sent messages");
                System.out.println("3. Display sender and recipient details"); 
                System.out.println("4. Display longest message");              
                System.out.println("5. Search messages by recipient");         
                System.out.println("6. Delete message by hash");               
                System.out.println("7. Logout");
                System.out.println("8. Exit App");
                System.out.print("Enter your choice: ");
                String choice = input.nextLine();

                switch (choice) {
                    case "1":
                        // Send Messages
                        int numMessages = 0;
                        String numInput = "";

                        while (true) {
                            System.out.print
                            ("How many messages do you want to send? ");
                            numInput = input.nextLine();

                            if (numInput.matches("\\d+")) {
                                numMessages = Integer.parseInt(numInput);
                                if (numMessages > 0) break;
                                else System.out.println("Please enter a"
                                        + " number greater than 0.");
                            } else {
                                System.out.println("Invalid input. "
                                        + "Please enter digits only.");
                            }
                        }

                        System.out.println("\nYou can send " + numMessages +
                                " messages:");
                        for (int i = 0; i < numMessages; i++) {
                            System.out.println("\n--- Message " + (i + 1) + 
                                    " of " + numMessages + " ---");
                            messageSystem.sendMessage();
                        }

                        System.out.println("\nTotal messages sent: " +
                                messageSystem.returnTotalMessages());
                        break;
                        
                    case "2":
                        // Show recently sent messages
                        System.out.println(messageSystem.printMessages());
                        break;
                        
                    case "3":
                        // Display sender and recipient details 
                        messageSystem.displaySenderAndRecipient();
                        break;
                        
                    case "4":
                        // Display longest message 
                        messageSystem.displayLongestMessage();
                        break;
                        
                    case "5":
                        // Search messages by recipient =
                        messageSystem.searchMessagesByRecipient();
                        break;
                        
                    case "6":
                        // Delete message by hash =
                        messageSystem.deleteMessageByHash();
                        break;
                        
                    case "7":
                        System.out.println("You have been logged out.");
                        inMainMenu = false;
                        break;
                        
                    case "8":
                        System.out.println("Exiting app. Goodbye!");
                        exitApp = true;
                        inMainMenu = false;
                        break;
                        
                    default:
                        System.out.println("Invalid choice. Please try again.");
                }
                
                // Pause for user to read output
                if (inMainMenu && !choice.equals("7") && !choice.equals("8")) {
                    System.out.println("\nPress Enter to continue...");
                    input.nextLine();
                }
            }
        }
        
        input.close();
    }
}
    //--------------------------------0o0o0o0o end file 0o0o------------------//

