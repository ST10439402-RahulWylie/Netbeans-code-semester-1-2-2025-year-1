/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package rahulwylie.st10439402.prog5121.part1;

import java.util.ArrayList;

/**
 *
 * @author lab_RahulWylie
 */
public class UserClass {
    
     //Users attributes
    private String username;
    private String password;
    private String cellNumber;
    private String firstName;
    private String lastName;
    
    // Array attributes for messaging functionality
    private ArrayList<String> sentMessageArray;
    private ArrayList<String> messageHashArray;
    private ArrayList<String> messageIDArray;
    private ArrayList<String> senderArray;
    private ArrayList<String> recipientArray;
            
    
    //Master conductor
    public UserClass(String username, String password, String cellNumber,
             String firstName, String lastName){
        this.username = username;
        this.password = password;
        this.cellNumber = cellNumber;
        this.firstName = firstName;
        this.lastName = lastName;
        
        // Initialize ArrayLists
        this.sentMessageArray = new ArrayList<>();
        this.messageHashArray = new ArrayList<>();
        this.messageIDArray = new ArrayList<>();
        this.senderArray = new ArrayList<>();
        this.recipientArray = new ArrayList<>();
    }   
    
    //Getters and setters for basic attributes
    public String getUsername(){
        return username;
    }
    
    public void setUsername(String username){
        this.username = username;
    }
    
    public String getPassword(){
        return password;
    }
    
    public void setPassword(String password){
        this.password = password;
    }
    
    public String getCellNumber(){
        return cellNumber;
    }
    
    public void setCellNumber(String cellNumber){
        this.cellNumber = cellNumber;
    }
    
    public String getFirstName(){
        return firstName;
    }
    
    public void setFirstName(String firstName){
        this.firstName = firstName;
    }
    
    public String getLastName(){
        return lastName;
    }
    
    public void setLastName(String lastName){
        this.lastName = lastName;
    }
    
    // Getter methods for arrays (useful for testing)
    public ArrayList<String> getSentMessageArray() {
        return sentMessageArray;
    }
    
    public ArrayList<String> getMessageHashArray() {
        return messageHashArray;
    }
    
    public ArrayList<String> getMessageIDArray() {
        return messageIDArray;
    }
    
    public ArrayList<String> getSenderArray() {
        return senderArray;
    }
    
    public ArrayList<String> getRecipientArray() {
        return recipientArray;
    }
}

//------------0o0o0o0o0o00o end file----------------------//