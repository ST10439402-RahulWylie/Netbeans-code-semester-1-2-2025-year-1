/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
import org.junit.Test;
import static org.junit.Assert.*;
import rahulwylie.st10439402.prog5121.part1.LoginClass;



/**
 *
 * @author lab_RahulWylie
 */
public class UnitTest {
    
    LoginClass login = new LoginClass();

   

    @Test
    public void testCorrectlyFormattedUsername() {
        boolean result = login.checkUserName("kyl_1");
        assertTrue("Username should be valid "
                + "(contains underscore and ≤ 5 chars)", result);
    }

    @Test
    public void testIncorrectlyFormattedUsername() {
        boolean result = login.checkUserName("kyle!ll!!");
        assertFalse("Username should be invalid "
                + "(missing underscore or too long)", result);
    }

    @Test
    public void testPasswordMeetsComplexity() {
        boolean result = login.checkPasswordComplexity("Ch&&sec@ke99|");
        assertTrue("Password should meet complexity requirements", result);
    }

    @Test
    public void testPasswordFailsComplexity() {
        boolean result = login.checkPasswordComplexity("password");
        assertFalse("Password should fail complexity "
                + "(no uppercase, digit, special char)", result);
    }

    @Test
    public void testCorrectCellPhoneFormat() {
        boolean result = login.checkCellPhoneNumber("+27838968976");
        assertTrue("Cell number should be correctly formatted", result);
    }

    @Test
    public void testIncorrectCellPhoneFormat() {
        boolean result = login.checkCellPhoneNumber("08966553");
        assertFalse("Cell number should be incorrectly formatted", result);
    }

    // Test successful registration and login process using assertEquals and assertTrue

    @Test
    public void testSuccessfulRegistrationAndLogin() {
        String regMsg = login.registerUser(
                "kyl_1", "Ch&&sec@ke99|", "+27838968976", "Rahul", "Wylie");
        assertEquals("Registration should be successful", 
                "User successfully captured.", regMsg);

        boolean loginResult = login.loginUser("kyl_1", "Ch&&sec@ke99|");
        assertTrue("Login should be successful", loginResult);

        String loginMsg = login.returnLoginStatus("kyl_1", "Ch&&sec@ke99|");
        assertEquals("Should return welcome message",
                     "Welcome RahulWylie it is great to see you again.",
                     loginMsg);
    }

    // Test failed login

    @Test
    public void testFailedLogin() {
        login.registerUser
        ("kyl_1", "Ch&&sec@ke99|", "+27838968976", "Rahul", "Wylie");

        boolean loginResult = login.loginUser("wrongUser", "wrongPass");
        assertFalse("Login should fail with incorrect credentials", 
                loginResult);

        String loginMsg = login.returnLoginStatus("wrongUser", "wrongPass");
        assertEquals("Should return failure message",
                     "Username or password incorrect, please try again.",
                     loginMsg);
    }
}

//--------------------0o0o0o0 end file 0o0o0----------------------------------//