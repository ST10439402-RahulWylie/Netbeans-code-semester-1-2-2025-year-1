/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package arithmeticoperation;

/**
 *
 * @author lab_RahulWylie_ST10439402
 */
public class ArithmeticOperation {

   
    public static void main(String[] args) {
        int firstNumber;
        int secondNumber;
        int sum;
        int difference;
        int average;
        
        Scanner input = new Scanner(System.in);
        
        System.out.println("Please enter an integer >> ");
        firstNumber = input.nextInt();
        
        System.out.println("Please enter another integer >> ");
        secondNumber = input.nextInt();
        
        sum = firstNumber + secondNumber;
        average = sum / 2;
        
        System.out.println("Sum" + sum);
        System.out.println("Difference:" + difference);
        System.out.println("Average:" + average);
                
                
        
        
        
    }
    
}
