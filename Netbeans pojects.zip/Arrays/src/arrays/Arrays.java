/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package arrays;

/**
 *
 * @author RahulWylie
 */
public class Arrays {

    
    public static void main(String[] args) {
       double[] salaries  = new double[4];
       
       salaries[0] = 12.25;
       salaries[1] = 13.55;
       salaries[2] = 14.25;
       salaries[3] = 16.85;
       
        System.out.println("salaries one bny one are:");
        System.out.println(salaries[0]);
        System.out.println(salaries[1]);
        System.out.println(salaries[2]);
        System.out.println(salaries[3]);

    }
    
}
