/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package myfirstjavaapplication;

/**
 *
 * @author Rahul Wylie ST10439402
 */
public class CostantAndVariables {
    
  static  final double MIN_VALUE =30;
  static String greeting = "Good day";
    
    //-------------------------------- My method -------------------------------
    public static void MyMethod(){
    
                final int MAX_VALUE = 20;
                double result = 0;
                
                result = MAX_VALUE * 4;
                
                System.out.println("The result is " + result);
                        
                }
    //---------------------------------------------------------------//
    //------------------------- Second method -----------------------//
    public static void secondMethod(){
            System.out.println(MIN_VALUE);
            System.out.println(greeting);
    
    }
            
    
}
