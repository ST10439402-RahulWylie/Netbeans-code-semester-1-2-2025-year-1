/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package myfirstjavaapplication;

/**
 *
 * @author lab_services_student
 */
public class RahulAndWylie {
    
    //Constants
    public static final int MAX_VALUE =100;
    public static final String APPLICATION_NAME ="MyApp";
    
    //-------------------------------------------------------------------------
    // Method to demonstrate constants and variables
    public static void RahulAndWylie(){
    
    //Variables
    int currentValue = 50;
    String message = "Hello World!";
    
    //Trying to change a constant (will cause a compilation error)
    //Max_VALUE = 200;
    
    //Changing a variable
    currentValue = 75;
        System.out.println("");
        System.out.println("=> Constant and Variables");
        System.out.println("Current value" + currentValue);            
        System.out.println("Message: " + message);
        System.out.println("MAX value: " + MAX_VALUE);
        System.out.println("Application name: " + APPLICATION_NAME);
        
        
        
    }
    
}
