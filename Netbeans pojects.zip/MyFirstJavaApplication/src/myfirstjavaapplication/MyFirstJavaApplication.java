package myfirstjavaapplication;

/**
 *
 * @author Rahul Wylie ST10439402
 */
public class MyFirstJavaApplication 
{

    // --------------- Main Method ------------- //
    public static void main(String[] args) {
        printMessage();
        differentDataTypes();
        CostantAndVariables.MyMethod();
        CostantAndVariables.secondMethod();
    }
    
    //-----------------------------------------------------------------------//
    
    //-------------------- Generate method -----------------------------------//
       private static void printMessage() {
             System.out.println("Hello World");
        
               
       }
       
       // -----------------------------------------------------------//
       
       static void differentDataTypes() {
           //Declaring variables of differnt data types
           int age = 30;
           double price = 19.99;
           boolean isStudent = true;
           char grade = 'A';
           String name = "John Doe";
           
          System.out.println(name + "is" + age + "years old");
    }
    
}
//--------------------$$$$$$$$ End of file line $$$$$$$$----------------------//